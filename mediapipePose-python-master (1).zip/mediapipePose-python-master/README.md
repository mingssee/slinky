# Slinky

## 필요 라이브러리 설치
```
pip3 install -r requirements.txt
```

## 서버 실행 명령어
```
python3 app.py
```
